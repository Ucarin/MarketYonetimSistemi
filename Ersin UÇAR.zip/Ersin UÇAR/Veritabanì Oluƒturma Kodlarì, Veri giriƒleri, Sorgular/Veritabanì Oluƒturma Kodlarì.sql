-- Veritaban�n� Olu�tur
CREATE DATABASE MarketYonetimSistemi1;
USE MarketYonetimSistemi1;

-- Sehirler Tablosu
CREATE TABLE Sehirler (
    SehirId INT PRIMARY KEY IDENTITY(1,1),
    SehirAdi NVARCHAR(20)
);

-- Ilceler Tablosu
CREATE TABLE Ilceler (
    IlceId INT PRIMARY KEY IDENTITY(1,1),
    IlceAdi NVARCHAR(20),
    SehirId INT
);

-- AdresDetay Tablosu
CREATE TABLE AdresDetay (
    AdresDetayId INT PRIMARY KEY IDENTITY(1,1),
    SehirId INT,
    IlceId INT,
    MahalleAdi NVARCHAR(20),
    SokakAdi NVARCHAR(20),
    SokakNo NVARCHAR(20),
    BinaNo NVARCHAR(6)
);

-- Adres Tablosu
CREATE TABLE Adres (
    AdresId INT PRIMARY KEY IDENTITY(1,1),
    AdresAdi NVARCHAR(20),
    AdresDetayId INT
);

--AdresAdi uzunlu�u 20 karaktere s��mad��� i�in de�i�tirdik karakter uzunlu�unu
ALTER TABLE Adres
ALTER COLUMN AdresAdi NVARCHAR(70);


-- Maas Tablosu
CREATE TABLE Maas (
    MaasId INT PRIMARY KEY IDENTITY(1,1),
    Maas DECIMAL(18, 2),
    MaasTuru NVARCHAR(15)
);

-- Rutbe Tablosu
CREATE TABLE Rutbe (
    RutbeId INT PRIMARY KEY IDENTITY(1,1),
    RutbeAdi NVARCHAR(20)
);

--RutbeAdi uzunlu�u 20 karaktere s��mad��� i�in de�i�tirdik karakter uzunlu�unu...
ALTER TABLE Rutbe
ALTER COLUMN RutbeAdi NVARCHAR(50);


-- Personel Tablosu
CREATE TABLE Personel (
    PersonelId INT PRIMARY KEY IDENTITY(1,1),
    PersonelAdi NVARCHAR(15),
    PersonelSoyadi NVARCHAR(20),
    TelefonNo NVARCHAR(20),
    AdresId INT,
    RutbeId INT,
    MaasId INT
);

ALTER TABLE Personel
ADD MarketId INT;

ALTER TABLE Personel
ADD CONSTRAINT FK_Personel_Market
FOREIGN KEY (MarketId)
REFERENCES Market(MarketId);

-- Market Tablosu
CREATE TABLE Market (
    MarketId INT PRIMARY KEY IDENTITY(1,1),
    MarketAdi NVARCHAR(25),
    AdresId INT
);

-- UreticiFirma Tablosu
CREATE TABLE UreticiFirma (
    UreticiFirmaId INT PRIMARY KEY IDENTITY(1,1),
    UreticiFirmaAdi NVARCHAR(30),
    AdresId INT

);

--isim uzunlu�u 30 karaktere s��mad��� i�in de�i�tirdik karakter uzunlu�unu
ALTER TABLE UreticiFirma
ALTER COLUMN UreticiFirmaAdi NVARCHAR(70);

-- Kampanya Tablosu
CREATE TABLE Kampanya (
    KampanyaId INT PRIMARY KEY IDENTITY(1,1),
    KampanyaAdi NVARCHAR(20),
    KampanyaIndirimTutari DECIMAL(18, 2),
    KampanyaBaslangicTarihi DATE,
    KampanyaBitisTarihi DATE,
    KampanyaAktifMi BIT
);

ALTER TABLE Kampanya
ALTER COLUMN KampanyaAdi NVARCHAR(50);

-- Satis Tablosu
CREATE TABLE Satis (
    SatisId INT PRIMARY KEY IDENTITY(1,1),
    MarketId INT,
    MusteriId INT,
    Tutar DECIMAL(18, 2),
    OdemeTipi NVARCHAR(20),
    SatisTarihi DATE,
	UrunId INT,
    KampanyaId INT,
    UrunAdet INT
);

-- Musteri Tablosu
CREATE TABLE Musteri (
    MusteriId INT PRIMARY KEY IDENTITY(1,1),
    MusteriAdi NVARCHAR(255),
    MusteriSoyadi NVARCHAR(255),
    MusteriUyelikTarihi DATE,
    MusteriEmail NVARCHAR(255),
    MusteriTelefon NVARCHAR(20),
    MusteriAdres NVARCHAR(500)
);

-- SatisDetay Tablosu


-- UrunKategori Tablosu
CREATE TABLE UrunKategori (
    UrunKategoriId INT PRIMARY KEY IDENTITY(1,1),
    UrunKategoriAdi NVARCHAR(20)
);

ALTER TABLE UrunKategori
ALTER COLUMN UrunKategoriAdi NVARCHAR(50);

-- ReyonKategori Tablosu
CREATE TABLE ReyonKategori (
    ReyonKategoriId INT PRIMARY KEY IDENTITY(1,1),
    ReyonKategoriAdi NVARCHAR(20)
);


ALTER TABLE ReyonKategori
ALTER COLUMN ReyonKategoriAdi NVARCHAR(50);

-- Raf Tablosu
CREATE TABLE Raf (
    RafId INT PRIMARY KEY IDENTITY(1,1),
    RafAdi NVARCHAR(20),
    ReyonId INT
);

ALTER TABLE Raf
ADD MarketId INT;

ALTER TABLE Raf
ADD CONSTRAINT FK_Raf_Market FOREIGN KEY (MarketId) REFERENCES Market(MarketId);

-- Reyon Tablosu
CREATE TABLE Reyon (
    ReyonId INT PRIMARY KEY IDENTITY(1,1),
    ReyonAdi NVARCHAR(20),
    MarketId INT,
    ReyonKategoriId INT
);

ALTER TABLE Reyon
ALTER COLUMN ReyonAdi NVARCHAR(50);

-- UrunStok Tablosu
CREATE TABLE UrunStok (
    UrunStokId INT PRIMARY KEY IDENTITY(1,1),
    MarketId INT,
    UrunId INT,
    UrunStokAdet INT,
    UrunStokTur NVARCHAR(15)
);

-- SatinAlim Tablosu
CREATE TABLE SatinAlim (
    SatinAlimId INT PRIMARY KEY IDENTITY(1,1),
    MarketId INT,
    UrunId INT,
    UreticiFirmaId INT
);

-- SatinAlimDetay Tablosu
CREATE TABLE SatinAlimDetay (
    SatinAlimDetayId INT PRIMARY KEY IDENTITY(1,1),
    SatinAlimId INT,
    Fiyat DECIMAL(18, 2),
    Miktar INT,
    Tarih DATE
);

-- Urun Tablosu
CREATE TABLE Urun (
    UrunId INT PRIMARY KEY IDENTITY(1,1),
    UrunAdi NVARCHAR(20),
    SonKullanmaTarihi DATE,
    UrunFiyat DECIMAL(18, 2),
    UreticiFirmaId INT,
    UrunKategoriId INT,
    ReyonId INT,
    RafId INT
);

-- Foreign Key'lerin Eklenmesi


ALTER TABLE Ilceler
ADD CONSTRAINT FK_Ilceler_Sehirler
FOREIGN KEY (SehirId) REFERENCES Sehirler(SehirId);


ALTER TABLE AdresDetay
ADD CONSTRAINT FK_AdresDetay_Sehirler
FOREIGN KEY (SehirId) REFERENCES Sehirler(SehirId);

ALTER TABLE AdresDetay
ADD CONSTRAINT FK_AdresDetay_Ilceler
FOREIGN KEY (IlceId) REFERENCES Ilceler(IlceId);


ALTER TABLE Adres
ADD CONSTRAINT FK_Adres_AdresDetay
FOREIGN KEY (AdresDetayId) REFERENCES AdresDetay(AdresDetayId);


ALTER TABLE Personel
ADD CONSTRAINT FK_Personel_Adres
FOREIGN KEY (AdresId) REFERENCES Adres(AdresId);

ALTER TABLE Personel
ADD CONSTRAINT FK_Personel_Rutbe
FOREIGN KEY (RutbeId) REFERENCES Rutbe(RutbeId);

ALTER TABLE Personel
ADD CONSTRAINT FK_Personel_Maas
FOREIGN KEY (MaasId) REFERENCES Maas(MaasId);


ALTER TABLE Market
ADD CONSTRAINT FK_Market_Adres
FOREIGN KEY (AdresId) REFERENCES Adres(AdresId);


ALTER TABLE UreticiFirma
ADD CONSTRAINT FK_UreticiFirma_Adres
FOREIGN KEY (AdresId) REFERENCES Adres(AdresId);


ALTER TABLE Satis
ADD CONSTRAINT FK_Satis_Market
FOREIGN KEY (MarketId) REFERENCES Market(MarketId);

ALTER TABLE Satis
ADD CONSTRAINT FK_Satis_Musteri
FOREIGN KEY (MusteriId) REFERENCES Musteri(MusteriId);


ALTER TABLE SatisDetay
ADD CONSTRAINT FK_SatisDetay_Satis
FOREIGN KEY (SatisId) REFERENCES Satis(SatisId);

ALTER TABLE SatisDetay
ADD CONSTRAINT FK_SatisDetay_Urun
FOREIGN KEY (UrunId) REFERENCES Urun(UrunId);

ALTER TABLE SatisDetay
ADD CONSTRAINT FK_SatisDetay_Kampanya
FOREIGN KEY (KampanyaId) REFERENCES Kampanya(KampanyaId);


ALTER TABLE Reyon
ADD CONSTRAINT FK_Reyon_Market
FOREIGN KEY (MarketId) REFERENCES Market(MarketId);

ALTER TABLE Reyon
ADD CONSTRAINT FK_Reyon_ReyonKategori
FOREIGN KEY (ReyonKategoriId) REFERENCES ReyonKategori(ReyonKategoriId);


ALTER TABLE Raf
ADD CONSTRAINT FK_Raf_Reyon
FOREIGN KEY (ReyonId) REFERENCES Reyon(ReyonId);


ALTER TABLE UrunStok
ADD CONSTRAINT FK_UrunStok_Market
FOREIGN KEY (MarketId) REFERENCES Market(MarketId);

ALTER TABLE UrunStok
ADD CONSTRAINT FK_UrunStok_Urun
FOREIGN KEY (UrunId) REFERENCES Urun(UrunId);


ALTER TABLE SatinAlim
ADD CONSTRAINT FK_SatinAlim_Market
FOREIGN KEY (MarketId) REFERENCES Market(MarketId);

ALTER TABLE SatinAlim
ADD CONSTRAINT FK_SatinAlim_Urun
FOREIGN KEY (UrunId) REFERENCES Urun(UrunId);

ALTER TABLE SatinAlim
ADD CONSTRAINT FK_SatinAlim_UreticiFirma
FOREIGN KEY (UreticiFirmaId) REFERENCES UreticiFirma(UreticiFirmaId);


ALTER TABLE SatinAlimDetay
ADD CONSTRAINT FK_SatinAlimDetay_SatinAlim
FOREIGN KEY (SatinAlimId) REFERENCES SatinAlim(SatinAlimId);


ALTER TABLE Urun
ADD CONSTRAINT FK_Urun_UreticiFirma
FOREIGN KEY (UreticiFirmaId) REFERENCES UreticiFirma(UreticiFirmaId);

ALTER TABLE Urun
ADD CONSTRAINT FK_Urun_UrunKategori
FOREIGN KEY (UrunKategoriId) REFERENCES UrunKategori(UrunKategoriId);

ALTER TABLE Urun
ADD CONSTRAINT FK_Urun_Reyon
FOREIGN KEY (ReyonId) REFERENCES Reyon(ReyonId);

ALTER TABLE Urun
ADD CONSTRAINT FK_Urun_Raf
FOREIGN KEY (RafId) REFERENCES Raf(RafId);


