--Sorgular:

--(1.sorgu)
--Belirli Bir Tarihte Yap�lan Sat��lar�n Toplam�n� Veren Sorgu
SELECT SUM(Satis.Tutar) AS ToplamTutar FROM Satis WHERE Satis.SatisTarihi = '2023-01-01';



--(2.sorgu)
--Belirli bir reyonda bulunan �r�n�n ad�n� ve fiyat�n� getiren sorgu
SELECT Urun.UrunAdi, Urun.UrunFiyat FROM Urun JOIN Raf ON Urun.RafId = Raf.RafId WHERE Raf.ReyonId =13;



--(3.sorgu)
--belirli bir kategoriye ait �r�nleri ad� ve fiyat� olarak listeleyen sorguyu fonksiyon olarak ekleme.
CREATE FUNCTION dbo.BelirliBirKategoriyeAitUrunler( @KategoriId INT) RETURNS TABLE AS
RETURN
(
    SELECT  U.UrunAdi, U.UrunFiyat FROM Urun U
    WHERE U.UrunKategoriId = @KategoriId
);
--fonksiyonu �a��rma 
SELECT * FROM dbo.BelirliBirKategoriyeAitUrunler(19);



--(4.sorgu)
--Kategori ad� 'kitap ve dergi' olan �r�nleri listeleyen sorguyu view yap�s� olarak veritaban�m�za kaydediyoruz
CREATE VIEW KitapVeDergi AS SELECT
    U.UrunId,
    U.UrunAdi,
    U.SonKullanmaTarihi,
    U.UrunFiyat,
    K.UrunKategoriAdi AS KategoriAdi
FROM
    Urun AS U
JOIN
    UrunKategori AS K ON U.UrunKategoriId = K.UrunKategoriId
WHERE
    K.UrunKategoriAdi = 'Kitap ve Dergi';

	--Viewden verileri �ekme
	SELECT * FROM KitapVeDergi;


	--(5.Sorgu)
	--personelleri ve oturdu�u illeri listeleyen sorgu.
	SELECT
    P.PersonelAdi,
    P.PersonelSoyadi,
    S.SehirAdi AS OturduguIl
	FROM
    Personel AS P
	JOIN
    Adres AS A ON P.AdresId = A.AdresId
	JOIN
    AdresDetay AS AD ON A.AdresDetayId = AD.AdresDetayId
	JOIN
    Sehirler AS S ON AD.SehirId = S.SehirId;


	--(6.Sorgu)
	--personel adi, soyadi ve r�tbe adlar�n� listeleyen sorgu
	SELECT
		PersonelAdi,
		PersonelSoyadi,
		RutbeAdi
	FROM
		Personel
	INNER JOIN
		Rutbe ON Personel.RutbeId = Rutbe.RutbeId;

	--(7.Sorgu)
	--Market tablosu ile Adres ve AdresDetay tablolar�n� birle�tirerek her marketin ad�n� ve adres bilgisini listeleyen bir sorgu.
	
		SELECT
		MarketAdi,
		MahalleAdi,
		SokakAdi,
		SokakNo,
		BinaNo
	FROM
		Market
	INNER JOIN
		Adres ON Market.AdresId = Adres.AdresId
	INNER JOIN
		AdresDetay ON Adres.AdresDetayId = AdresDetay.AdresDetayId;

		
	--(8.Sorgu)
	--Personellerin ald��� ortalama maa�lar� hesaplayan sorgu
	SELECT
	AVG(Maas) AS OrtalamaMaas
	FROM
	Maas ;

	--(9.Sorgu)
	--Toplam sat�� adetine g�re en �ok satan �r�n� bulan ve sat�� adetini veren sorgu
		SELECT
		TOP 1
		UrunAdi,
		SUM(UrunAdet) AS ToplamSatisAdeti
	FROM
		Satis
	INNER JOIN
		Urun ON Satis.UrunId = Urun.UrunId
	GROUP BY
		UrunAdi
	ORDER BY
		ToplamSatisAdeti DESC;

	--(10.Sorgu)
	--T�m marketlerdeki toplam personel say�s�n� veren sorgu
	SELECT
    COUNT(PersonelId) AS PersonelSayisi
	FROM
    Personel;

	--(11.Sorgu)
	--Aktif kampanya say�s�n� bulan sorgu
		SELECT
		COUNT(KampanyaId) AS AktifKampanyaSayisi
	FROM
		Kampanya
	WHERE
		KampanyaAktifMi = 1;


	--(12.Sorgu)
	--Her �r�nden ka� adet sat�ld���n� veren sorgu

	SELECT UrunAdi,
		SUM(UrunAdet) AS ToplamSatisAdeti
	FROM
		Satis
	INNER JOIN
		Urun ON Satis.UrunId = Urun.UrunId
	GROUP BY
		UrunAdi;


	--(13.Sorgu)
	-- marketlerdeki toplam sat�� adetini bulan sorgu

		SELECT MarketAdi, COUNT(*) AS ToplamSatisAdeti
	FROM
		Satis
	INNER JOIN
		Market ON Satis.MarketId = Market.MarketId
	GROUP BY
		MarketAdi;


	--(14.Sorgu)
	--�r�n fiyat� 10'dan k���kse "Ucuz", 10 ile 50 aras�ndaysa "Orta"
	--50'den b�y�kse fiyatkategori s�tununa pahal� yazan sorgu.

	SELECT
    UrunAdi,
    UrunFiyat,
    CASE
        WHEN UrunFiyat < 10 THEN 'Ucuz'
        WHEN UrunFiyat >= 10 AND UrunFiyat < 50 THEN 'Orta'
        WHEN UrunFiyat >= 50 THEN 'Pahal�'
        ELSE 'Belirlenemiyor'
    END AS FiyatKategori
	FROM
    Urun;

	--(15.Sorgu)
	--Belirtilen �retici firman�n �r�nlerini listeleyen sorgu

		SELECT Urun.UrunAdi, Urun.UrunFiyat
	FROM Urun
	INNER JOIN UreticiFirma ON Urun.UreticiFirmaId = UreticiFirma.UreticiFirmaId
	WHERE UreticiFirma.UreticiFirmaAdi = 'Do�al S�t �r�nleri Ltd. �ti.';


	--(16. Sorgu)
	--Belirtilen m��teriye yap�lan t�m sat��lar� listeleyen sorgu

		SELECT Satis.SatisId, Satis.Tutar, Satis.SatisTarihi, Urun.UrunAdi
	FROM Satis
	INNER JOIN Musteri ON Satis.MusteriId = Musteri.MusteriId
	INNER JOIN Urun ON Satis.UrunId = Urun.UrunId
	WHERE Musteri.MusteriAdi = 'Ahmet' ;


	--(17.Sorgu)
	--En �ok sto�u bulunan(adet olarak) �r�n� yazd�ran sorgu.
	SELECT TOP 1 Urun.UrunAdi, SUM(UrunStok.UrunStokAdet) AS ToplamStok
	FROM Urun
	JOIN UrunStok ON Urun.UrunId = UrunStok.UrunId
	GROUP BY Urun.UrunAdi
	ORDER BY ToplamStok DESC;

	--(18.Sorgu)
	--18.	Her �retici firman�n adreslerini adres detaylar�yla birlikte listeleyen sorgu 
	
		SELECT UreticiFirma.UreticiFirmaAdi, AdresDetay.*
	FROM UreticiFirma
	JOIN Adres ON UreticiFirma.AdresId = Adres.AdresId
	JOIN AdresDetay ON Adres.AdresDetayId = AdresDetay.AdresDetayId;


	--(19.sorgu)
	--Sat�� yapmayan marketlerin hepsini listeleyen sorgu
			SELECT Market.MarketAdi
		FROM Market
		LEFT JOIN Satis ON Market.MarketId = Satis.MarketId
		WHERE Satis.SatisId IS NULL;


		--(20.Sorgu)
		--En yeni kampanyalar� listeleyen sorgu

		SELECT TOP 5 KampanyaAdi, KampanyaBaslangicTarihi, KampanyaBitisTarihi
		FROM Kampanya
		ORDER BY KampanyaBaslangicTarihi DESC;
