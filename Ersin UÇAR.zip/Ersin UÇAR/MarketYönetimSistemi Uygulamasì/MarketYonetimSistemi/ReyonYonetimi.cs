﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class ReyonYonetimi : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;
        private DataTable reyonDataTable;
        private DataTable rafDataTable;

        public ReyonYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();

            // Initialize and fill DataGridView controls with data
            VerileriDoldur();
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Open the connection
                baglanti.BaglantiAc();

                // Update Reyon data
                using (SqlDataAdapter reyonAdapter = new SqlDataAdapter("SELECT * FROM Reyon", baglanti.Baglanti))
                using (SqlCommandBuilder reyonBuilder = new SqlCommandBuilder(reyonAdapter))
                {
                    reyonAdapter.Update(reyonDataTable);
                }

                // Update Raf data
                using (SqlDataAdapter rafAdapter = new SqlDataAdapter("SELECT * FROM Raf", baglanti.Baglanti))
                using (SqlCommandBuilder rafBuilder = new SqlCommandBuilder(rafAdapter))
                {
                    rafAdapter.Update(rafDataTable);
                }

                MessageBox.Show("Veriler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Close the connection
                baglanti.BaglantiKapat();
            }

            // Optional: Refresh the data after saving changes
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void VerileriDoldur()
        {
            try
            {
                // Open the connection
                baglanti.BaglantiAc();

                // Load data from Reyon table
                using (SqlDataAdapter reyonAdapter = new SqlDataAdapter("SELECT * FROM Reyon", baglanti.Baglanti))
                {
                    reyonDataTable = new DataTable();
                    reyonAdapter.Fill(reyonDataTable);
                    dataGridView1.DataSource = reyonDataTable;
                }

                // Load data from Raf table
                using (SqlDataAdapter rafAdapter = new SqlDataAdapter("SELECT * FROM Raf", baglanti.Baglanti))
                {
                    rafDataTable = new DataTable();
                    rafAdapter.Fill(rafDataTable);
                    dataGridView2.DataSource = rafDataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Close the connection
                baglanti.BaglantiKapat();
            }
        }

  
    }
}
