﻿namespace MarketYonetimSistemi
{
    partial class AnaSayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnaSayfa));
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_UrunYonetimi = new System.Windows.Forms.Button();
            this.btn_SatinAlimYonetimi = new System.Windows.Forms.Button();
            this.btn_stokYonetimi = new System.Windows.Forms.Button();
            this.btn_kampanyayonetim = new System.Windows.Forms.Button();
            this.btn_Personelyonetimi = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.btn_MusteriKaydet = new System.Windows.Forms.Button();
            this.btn_UreticiFirmaEkle = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.panel4 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Cooper Black", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(292, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(301, 55);
            this.label1.TabIndex = 0;
            this.label1.Text = "Market Adı";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.OrangeRed;
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1168, 119);
            this.panel1.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(39, 23);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(80, 63);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.OrangeRed;
            this.panel2.Controls.Add(this.button2);
            this.panel2.Controls.Add(this.btn_UrunYonetimi);
            this.panel2.Controls.Add(this.btn_SatinAlimYonetimi);
            this.panel2.Controls.Add(this.btn_stokYonetimi);
            this.panel2.Controls.Add(this.btn_kampanyayonetim);
            this.panel2.Location = new System.Drawing.Point(0, 118);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(166, 532);
            this.panel2.TabIndex = 2;
            // 
            // btn_UrunYonetimi
            // 
            this.btn_UrunYonetimi.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UrunYonetimi.Location = new System.Drawing.Point(12, 221);
            this.btn_UrunYonetimi.Name = "btn_UrunYonetimi";
            this.btn_UrunYonetimi.Size = new System.Drawing.Size(137, 66);
            this.btn_UrunYonetimi.TabIndex = 4;
            this.btn_UrunYonetimi.Text = "Ürün Yönetimi";
            this.btn_UrunYonetimi.UseVisualStyleBackColor = true;
            this.btn_UrunYonetimi.Click += new System.EventHandler(this.btn_UrunYonetimi_Click);
            // 
            // btn_SatinAlimYonetimi
            // 
            this.btn_SatinAlimYonetimi.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SatinAlimYonetimi.Location = new System.Drawing.Point(12, 124);
            this.btn_SatinAlimYonetimi.Name = "btn_SatinAlimYonetimi";
            this.btn_SatinAlimYonetimi.Size = new System.Drawing.Size(137, 66);
            this.btn_SatinAlimYonetimi.TabIndex = 3;
            this.btn_SatinAlimYonetimi.Text = "Satın Alım Yönetimi";
            this.btn_SatinAlimYonetimi.UseVisualStyleBackColor = true;
            this.btn_SatinAlimYonetimi.Click += new System.EventHandler(this.btn_SatinAlimYonetimi_Click);
            // 
            // btn_stokYonetimi
            // 
            this.btn_stokYonetimi.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_stokYonetimi.Location = new System.Drawing.Point(12, 22);
            this.btn_stokYonetimi.Name = "btn_stokYonetimi";
            this.btn_stokYonetimi.Size = new System.Drawing.Size(137, 66);
            this.btn_stokYonetimi.TabIndex = 2;
            this.btn_stokYonetimi.Text = "Stok Durumu";
            this.btn_stokYonetimi.UseVisualStyleBackColor = true;
            this.btn_stokYonetimi.Click += new System.EventHandler(this.btn_stokYonetimi_Click);
            // 
            // btn_kampanyayonetim
            // 
            this.btn_kampanyayonetim.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_kampanyayonetim.Location = new System.Drawing.Point(12, 316);
            this.btn_kampanyayonetim.Name = "btn_kampanyayonetim";
            this.btn_kampanyayonetim.Size = new System.Drawing.Size(137, 66);
            this.btn_kampanyayonetim.TabIndex = 1;
            this.btn_kampanyayonetim.Text = "Kampanya Yönetimi";
            this.btn_kampanyayonetim.UseVisualStyleBackColor = true;
            this.btn_kampanyayonetim.Click += new System.EventHandler(this.btn_kampanyayonetim_Click);
            // 
            // btn_Personelyonetimi
            // 
            this.btn_Personelyonetimi.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Personelyonetimi.Location = new System.Drawing.Point(18, 124);
            this.btn_Personelyonetimi.Name = "btn_Personelyonetimi";
            this.btn_Personelyonetimi.Size = new System.Drawing.Size(137, 66);
            this.btn_Personelyonetimi.TabIndex = 0;
            this.btn_Personelyonetimi.Text = "Personel Yönetimi";
            this.btn_Personelyonetimi.UseVisualStyleBackColor = true;
            this.btn_Personelyonetimi.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.OrangeRed;
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.btn_MusteriKaydet);
            this.panel3.Controls.Add(this.btn_UreticiFirmaEkle);
            this.panel3.Controls.Add(this.btn_Personelyonetimi);
            this.panel3.Location = new System.Drawing.Point(1002, 118);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(166, 532);
            this.panel3.TabIndex = 3;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(18, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 66);
            this.button1.TabIndex = 2;
            this.button1.Text = "Satıs Yap";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // btn_MusteriKaydet
            // 
            this.btn_MusteriKaydet.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MusteriKaydet.Location = new System.Drawing.Point(18, 221);
            this.btn_MusteriKaydet.Name = "btn_MusteriKaydet";
            this.btn_MusteriKaydet.Size = new System.Drawing.Size(137, 66);
            this.btn_MusteriKaydet.TabIndex = 1;
            this.btn_MusteriKaydet.Text = "Müsteri Kaydet";
            this.btn_MusteriKaydet.UseVisualStyleBackColor = true;
            this.btn_MusteriKaydet.Click += new System.EventHandler(this.btn_MusteriKaydet_Click);
            // 
            // btn_UreticiFirmaEkle
            // 
            this.btn_UreticiFirmaEkle.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_UreticiFirmaEkle.Location = new System.Drawing.Point(18, 316);
            this.btn_UreticiFirmaEkle.Name = "btn_UreticiFirmaEkle";
            this.btn_UreticiFirmaEkle.Size = new System.Drawing.Size(137, 66);
            this.btn_UreticiFirmaEkle.TabIndex = 1;
            this.btn_UreticiFirmaEkle.Text = "Üretici Firma Ekle";
            this.btn_UreticiFirmaEkle.UseVisualStyleBackColor = true;
            this.btn_UreticiFirmaEkle.Click += new System.EventHandler(this.btn_UreticiFirmaEkle_Click_1);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(384, 152);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(387, 348);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.OrangeRed;
            this.panel4.Location = new System.Drawing.Point(155, 531);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(857, 119);
            this.panel4.TabIndex = 6;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Cooper Black", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(12, 413);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(137, 66);
            this.button2.TabIndex = 5;
            this.button2.Text = "Stok Yönetimi";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // AnaSayfa
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1164, 647);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel4);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AnaSayfa";
            this.Text = "Ana Sayfa";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AnaSayfa_FormClosing);
            this.Load += new System.EventHandler(this.AnaSayfa_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Button btn_Personelyonetimi;
        private System.Windows.Forms.Button btn_kampanyayonetim;
        private System.Windows.Forms.Button btn_stokYonetimi;
        private System.Windows.Forms.Button btn_SatinAlimYonetimi;
        private System.Windows.Forms.Button btn_UrunYonetimi;
        private System.Windows.Forms.Button btn_UreticiFirmaEkle;
        private System.Windows.Forms.Button btn_MusteriKaydet;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button button2;
    }
}