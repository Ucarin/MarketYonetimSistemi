﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class AnaSayfa : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;
        

        public AnaSayfa(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();
        }

        private void AnaSayfa_Load(object sender, EventArgs e)
        {
            // Bağlantıyı aç
            baglanti.BaglantiAc();

            // Market adını al
            string marketAdi = GetMarketAdiById(secilenMarketId);

            // Label'a market adını yaz
            label1.Text = marketAdi+"e Hosgeldiniz";

            // Bağlantıyı kapat
            baglanti.BaglantiKapat();
        }

        private string GetMarketAdiById(int marketId)
        {
            string marketAdi = string.Empty;

            try
            {
                // SQL sorgusu
                string sorgu = "SELECT MarketAdi FROM Market WHERE MarketId = @MarketId";

                // SqlCommand nesnesi oluşturulması
                using (SqlCommand komut = new SqlCommand(sorgu, baglanti.Baglanti))
                {
                    // Parametre eklenmesi
                    komut.Parameters.AddWithValue("@MarketId", marketId);

                    // Sorgunun çalıştırılması ve sonucun okunması
                    SqlDataReader okuyucu = komut.ExecuteReader();
                    if (okuyucu.Read())
                    {
                        marketAdi = okuyucu["MarketAdi"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }

            return marketAdi;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void AnaSayfa_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 form1Gecis = new Form1();
            form1Gecis.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            PersonelYonetimi personelYonetimiGecis = new PersonelYonetimi(secilenMarketId);
            personelYonetimiGecis.Show();
        }

        private void btn_kampanyayonetim_Click(object sender, EventArgs e)
        {
            this.Hide();
            KampanyaYonetimi kampanyaYonetimiGecis = new KampanyaYonetimi(secilenMarketId);
            kampanyaYonetimiGecis.Show();
        }

        private void btn_stokYonetimi_Click(object sender, EventArgs e)
        {
            this.Hide();
            StokDurumu stokYonetimiGecis = new StokDurumu(secilenMarketId);
            stokYonetimiGecis .Show();
        }

        private void btn_SatinAlimYonetimi_Click(object sender, EventArgs e)
        {
            this.Hide();
            SatınAlımYonetimi satınAlımYonetimiGecis = new SatınAlımYonetimi(secilenMarketId);
            satınAlımYonetimiGecis.Show ();
        }

        private void btn_UrunYonetimi_Click(object sender, EventArgs e)
        {
            this.Hide();
            UrunYonetimi urunYonetimiGecis = new UrunYonetimi(secilenMarketId);
            urunYonetimiGecis.Show();
        }

  

        private void btn_UreticiFirmaEkle_Click_1(object sender, EventArgs e)
        {
            this.Hide() ;
            UreticiFirmaEkle ureticiFirmaEkleGecis = new UreticiFirmaEkle(secilenMarketId);
            ureticiFirmaEkleGecis .Show();
        }

        private void btn_MusteriKaydet_Click(object sender, EventArgs e)
        {
            this.Hide() ;   
            MusteriEkle musteriEkleGecis = new MusteriEkle(secilenMarketId);
            musteriEkleGecis .Show();
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            SatisYap satisYapGecis = new SatisYap(secilenMarketId);
            satisYapGecis .Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            StokYonetimi stokYonetimiGecis = new StokYonetimi(secilenMarketId);
            stokYonetimiGecis .Show();
        }
    }
}
