﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class SatinAlimDetay : Form
    {
        private DataTable dataTable;
        private SqlDataAdapter dataAdapter;
        private BaglantiDB baglanti;
        private int secilenMarketId;

        public SatinAlimDetay(int secilenMarketId)
        {
            InitializeComponent();
            baglanti = new BaglantiDB();
            this.secilenMarketId = secilenMarketId;


            // SatinAlimDetay formu yüklendiğinde SatinAlimDetay tablosunu getir
            SatinAlimDetayListele();
        }

        // SatinAlimDetay tablosunu DataGridView'da listeleme
        private void SatinAlimDetayListele()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT SD.*\r\nFROM SatinAlimDetay SD\r\nINNER JOIN SatinAlim SA ON SD.SatinAlimId = SA.SatinAlimId\r\nWHERE SA.MarketId = 1;";

                // SqlDataAdapter nesnesi oluşturulması
                dataAdapter = new SqlDataAdapter(sorgu, baglanti.Baglanti);

                // DataTable oluşturulması
                dataTable = new DataTable();

                // Verilerin DataSet'e doldurulması
                dataAdapter.Fill(dataTable);

                // DataGridView'a DataSource olarak atanması
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        // DataGridView'da yapılan değişiklikleri kaydet
       

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SqlCommandBuilder nesnesi oluşturulması
                using (SqlCommandBuilder builder = new SqlCommandBuilder(dataAdapter))
                {
                    // DataTable'daki değişiklikleri kaydet
                    dataAdapter.Update(dataTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
                SatinAlimDetayListele();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();          

        }

        private void SatinAlimDetay_Load(object sender, EventArgs e)
        {

        }
    }
}
