﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class PersonelYonetimi : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;

        public PersonelYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();

            // DataGridView'a veri yükleme
            VerileriYukle();
        }

        private void VerileriYukle()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM Personel WHERE MarketId = @MarketId";

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti))
                {
                    // Parametre eklenmesi
                    adapter.SelectCommand.Parameters.AddWithValue("@MarketId", secilenMarketId);

                    // DataTable oluşturulması
                    DataTable dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    adapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // DataTable'daki değişiklikleri güncellemek için SqlCommandBuilder kullanabilirsiniz
                using (SqlCommandBuilder builder = new SqlCommandBuilder())
                {
                    // SqlDataAdapter nesnesi oluşturulması
                    using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Personel WHERE MarketId = @MarketId", baglanti.Baglanti))
                    {
                        // Parametre eklenmesi
                        adapter.SelectCommand.Parameters.AddWithValue("@MarketId", secilenMarketId);

                        // SqlCommandBuilder'a güncelleme komutunu oluşturması için adapter'ı atayın
                        builder.DataAdapter = adapter;

                        // DataTable'daki değişiklikleri kaydet
                        builder.DataAdapter.Update((DataTable)dataGridView1.DataSource);
                    }
                }

                MessageBox.Show("Veriler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }

            VerileriYukle();
        }


        private void PersonelYonetimi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
        }

        private void PersonelYonetimi_Load(object sender, EventArgs e)
        {
           

        }

        private void button1_Click(object sender, EventArgs e)
        {
            AdresTablosu adresTablosuGecis = new AdresTablosu();
            adresTablosuGecis.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MaasTablosu maasTablosuGecis = new MaasTablosu();
            maasTablosuGecis.Show();    
        }

        private void button3_Click(object sender, EventArgs e)
        {
            RutbeTablosu rutbeTablosuGecis = new RutbeTablosu();
            rutbeTablosuGecis.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdresDetayTablosu adresDetayTablosuGecis = new AdresDetayTablosu();
            adresDetayTablosuGecis.Show();
        }
    }
}
