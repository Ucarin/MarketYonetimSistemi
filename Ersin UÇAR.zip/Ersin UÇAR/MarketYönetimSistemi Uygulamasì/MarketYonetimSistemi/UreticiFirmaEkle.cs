﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class UreticiFirmaEkle : Form
    {
        private BaglantiDB baglanti;
        private DataTable ureticiFirmaTable;
        private SqlDataAdapter adapter;
        private int secilenMarketId;

        public UreticiFirmaEkle(int secilenMarketId)
        {
            InitializeComponent();
            baglanti = new BaglantiDB();
            VerileriDoldur();
            this.secilenMarketId = secilenMarketId;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            // Eğer bir önceki formdan bir MarketId almanız gerekiyorsa buraya ekleyebilirsiniz.
            // Ancak şu anda MarketId'yi kullanmıyorsunuz gibi görünüyor.
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
        }

        private void VerileriDoldur()
        {
            try
            {
                baglanti.BaglantiAc();

                // DataGridView için SQL sorgusu
                string sorgu = "SELECT UreticiFirmaId, UreticiFirmaAdi, AdresId FROM UreticiFirma";
                adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti);

                // DataTable oluşturulması ve verilerin DataSet'e doldurulması
                ureticiFirmaTable = new DataTable();
                adapter.Fill(ureticiFirmaTable);

                // DataGridView'a DataSource olarak atanması
                dataGridView1.DataSource = ureticiFirmaTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.BaglantiKapat();
            }
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.BaglantiAc();

                // SqlCommandBuilder nesnesi oluşturulması
                using (SqlCommandBuilder builder = new SqlCommandBuilder(adapter))
                {
                    // DataTable'daki değişiklikleri kaydet
                    adapter.Update(ureticiFirmaTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
                VerileriDoldur();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.BaglantiKapat();
            }
        }

        private void UreticiFirmaEkle_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}
