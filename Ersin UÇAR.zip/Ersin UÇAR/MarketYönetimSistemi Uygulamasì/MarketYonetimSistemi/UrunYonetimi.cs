﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class UrunYonetimi : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;

        public UrunYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
          
        }
        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Urun", baglanti.Baglanti))
                {
                    // SqlCommandBuilder'a güncelleme komutunu oluşturması için adapter'ı atayın
                    using (SqlCommandBuilder builder = new SqlCommandBuilder(adapter))
                    {
                        // DataTable oluşturulması
                        DataTable dataTable = (DataTable)dataGridView1.DataSource;

                        // DataTable'daki değişiklikleri kaydet
                        adapter.Update(dataTable);
                    }
                }

                MessageBox.Show("Veriler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }

            VerileriDoldur(); // Optional: Refresh the data after saving changes
        }

        private void VerileriDoldur()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM Urun";

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti))
                {
                    // DataTable oluşturulması
                    DataTable dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    adapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        
        }

        private void UrunYonetimi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btn_KategoriYonetimi_Click(object sender, EventArgs e)
        {
            
            KategoriYonetimi kategoriYonetimiGecis = new KategoriYonetimi(secilenMarketId);
            kategoriYonetimiGecis.Show();
        }

        private void btn_ReyonYonetimi_Click(object sender, EventArgs e)
        {
            ReyonYonetimi reyonYonetimiGecis = new ReyonYonetimi(secilenMarketId);
            reyonYonetimiGecis.Show();
        }

        private void UrunYonetimi_Load(object sender, EventArgs e)
        {
            
        }
    }
}
