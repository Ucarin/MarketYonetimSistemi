﻿using System;
using System.Data.SqlClient;

namespace MarketYonetimSistemi
{
    internal class BaglantiDB : IDisposable
    {
        public SqlConnection Baglanti = new SqlConnection(@"Data Source=DESKTOP-VKB789V;Initial Catalog=MarketYonetimSistemi;Integrated Security=True");

        public void BaglantiAc()
        {
            try
            {
                // Bağlantıyı açın
                Baglanti.Open();
                Console.WriteLine("Bağlantı oluşturuldu.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Bağlantı hatası: {ex.Message}");
            }
        }

        public void BaglantiKapat()
        {
            try
            {
                // Bağlantıyı kapatın
                Baglanti.Close();
                Console.WriteLine("Bağlantı kapatıldı.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Bağlantı kapatma hatası: {ex.Message}");
            }
        }

        // IDisposable arabirimini uygula
        public void Dispose()
        {
            // Bağlantıyı kapat
            BaglantiKapat();
        }
    }
}