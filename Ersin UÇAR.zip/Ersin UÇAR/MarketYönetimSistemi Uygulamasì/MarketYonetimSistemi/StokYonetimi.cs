﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class StokYonetimi : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;
        private DataTable urunStokTable;
        private SqlDataAdapter adapter;

        public StokYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                baglanti.BaglantiAc();

                // SqlCommandBuilder nesnesi oluşturulması
                using (SqlCommandBuilder builder = new SqlCommandBuilder(adapter))
                {
                    // DataTable'daki değişiklikleri kaydet
                    adapter.Update(urunStokTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.BaglantiKapat();
            }
        }

        private void VerileriDoldur()
        {
            try
            {
                baglanti.BaglantiAc();

                // DataGridView için SQL sorgusu
                string sorgu = $"SELECT * FROM UrunStok WHERE MarketId = @MarketId";
                adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti);

                adapter.SelectCommand.Parameters.AddWithValue("@MarketId", secilenMarketId);
                urunStokTable = new DataTable();
                adapter.Fill(urunStokTable);

                // DataGridView'a DataSource olarak atanması
                dataGridView1.DataSource = urunStokTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.BaglantiKapat();
            }
        }

        private void StokYonetimi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UrunTablosu urunTablosuGecis = new UrunTablosu();
            urunTablosuGecis.Show();
        }
    }
}
