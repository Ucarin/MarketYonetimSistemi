﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class KampanyaYonetimi : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;

        private void KampanyaYonetimi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        public KampanyaYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM Kampanya", baglanti.Baglanti))
                {
                    // SqlCommandBuilder'a güncelleme komutunu oluşturması için adapter'ı atayın
                    using (SqlCommandBuilder builder = new SqlCommandBuilder(adapter))
                    {
                        // DataTable oluşturulması
                        DataTable dataTable = (DataTable)dataGridView1.DataSource;

                        // Yeni verileri ekleyin (istediğiniz sabit veriler)
                        DataRow row = dataTable.NewRow();
                        row["KampanyaId"] = 1;
                        row["KampanyaAdi"] = "Kampanya Adı";
                        row["KampanyaIndirimTutari"] = 10.0;
                        row["KampanyaBaslangicTarihi"] = DateTime.Now;
                        row["KampanyaBitisTarihi"] = DateTime.Now.AddDays(7);

                        // CheckBox sütunundaki değeri alın
                        DataGridViewCheckBoxCell checkBoxCell = (DataGridViewCheckBoxCell)dataGridView1.Rows[0].Cells["KampanyaAktifMi"];
                        row["KampanyaAktifMi"] = (bool)checkBoxCell.Value;

                      

                        // DataTable'daki değişiklikleri kaydet
                        adapter.Update(dataTable);
                    }
                }

                MessageBox.Show("Veriler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }


            VerileriDoldur();
        }


        private void VerileriDoldur()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT KampanyaId, KampanyaAdi, KampanyaIndirimTutari, KampanyaBaslangicTarihi, KampanyaBitisTarihi, KampanyaAktifMi FROM Kampanya";

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti))
                {
                    // DataTable oluşturulması
                    DataTable dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    adapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;

                    // KampanyaAktifMi sütunu var mı kontrol et
                    if (!dataGridView1.Columns.Contains("KampanyaAktifMi"))
                    {
                        // KampanyaAktifMi sütununu bool olarak göstermek için DataGridViewCheckBoxColumn ekleyin
                        DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
                        checkBoxColumn.DataPropertyName = "KampanyaAktifMi";
                        dataGridView1.Columns.Add(checkBoxColumn);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

       
    }
}
