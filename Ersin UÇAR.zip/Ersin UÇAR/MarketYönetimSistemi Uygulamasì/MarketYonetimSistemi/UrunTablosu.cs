﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class UrunTablosu : Form
    {
        private BaglantiDB baglanti;
        public UrunTablosu()
        {
            InitializeComponent();
            baglanti = new BaglantiDB();
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UrunTablosu_Load(object sender, EventArgs e)
        {

        }

        private void VerileriDoldur()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM Urun";

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti))
                {
                    // DataTable oluşturulması
                    DataTable dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    adapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }
    }
}
