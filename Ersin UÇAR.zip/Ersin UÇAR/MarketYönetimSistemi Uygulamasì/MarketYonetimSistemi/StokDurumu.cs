﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class StokDurumu : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;
        private DataTable dataTable;
        private SqlDataAdapter dataAdapter;

        public StokDurumu(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();

            // Giriş yapılan markete ait ürün stoklarını DataGridView'da listeleyelim
            UrunStokListele();
        }

        private void UrunStokListele()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu =" SELECT UrunStok.UrunStokId, Urun.UrunAdi, Urun.UrunFiyat, " +
                                   "UrunStok.UrunStokAdet, UrunStok.UrunStokTur, UrunStok.MarketId, " +
                                   "UreticiFirma.UreticiFirmaAdi, Reyon.ReyonAdi " +
                                   "FROM UrunStok " +
                                   "INNER JOIN Urun ON UrunStok.UrunId = Urun.UrunId " +
                                   "INNER JOIN UreticiFirma ON Urun.UreticiFirmaId = UreticiFirma.UreticiFirmaId " +
                                   "INNER JOIN Reyon ON Urun.ReyonId = Reyon.ReyonId " +
                                   "WHERE UrunStok.MarketId = @MarketId";
                // SqlCommand nesnesi oluşturulması
                using (SqlCommand komut = new SqlCommand(sorgu, baglanti.Baglanti))
                {
                    // Parametre eklenmesi
                    komut.Parameters.AddWithValue("@MarketId", secilenMarketId);

                    // SqlDataAdapter nesnesi oluşturulması
                    dataAdapter = new SqlDataAdapter(komut);

                    // DataTable oluşturulması
                    dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    dataAdapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
         
       
        }

       

        private void StokYonetimi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void StokDurumu_Load(object sender, EventArgs e)
        {

        }
    }
}
