﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class MusteriEkle : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;
        private DataTable musteriDataTable;

        public MusteriEkle(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();

            // Initialize and fill DataGridView control with data
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Save changes when the button is clicked
            Kaydet();
        }

        private void VerileriDoldur()
        {
            try
            {
                // Open the connection
                baglanti.BaglantiAc();

                // Load data from Musteri table
                using (SqlDataAdapter musteriAdapter = new SqlDataAdapter("SELECT * FROM Musteri", baglanti.Baglanti))
                {
                    musteriDataTable = new DataTable();
                    musteriAdapter.Fill(musteriDataTable);
                    dataGridView1.DataSource = musteriDataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Close the connection
                baglanti.BaglantiKapat();
            }
        }

        private void Kaydet()
        {
            try
            {
                // Open the connection
                baglanti.BaglantiAc();

                // Update Musteri data
                using (SqlDataAdapter musteriAdapter = new SqlDataAdapter("SELECT * FROM Musteri", baglanti.Baglanti))
                using (SqlCommandBuilder musteriBuilder = new SqlCommandBuilder(musteriAdapter))
                {
                    musteriAdapter.Update(musteriDataTable);
                }

                MessageBox.Show("Veriler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Close the connection
                baglanti.BaglantiKapat();
            }
        }

        private void MusteriEkle_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
    }
}