﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class KategoriYonetimi : Form
    {
        private int secilenMarketId;
        private BaglantiDB baglanti;
        private DataTable dataTable; // DataTable to hold data

        public KategoriYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();

            // Initialize and fill the DataGridView with data
            VerileriDoldur();
        }

        private void btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter("SELECT * FROM UrunKategori", baglanti.Baglanti))
                {
                    // SqlCommandBuilder'a güncelleme komutunu oluşturması için adapter'ı atayın
                    using (SqlCommandBuilder builder = new SqlCommandBuilder(adapter))
                    {
                        // DataTable'daki değişiklikleri kaydet
                        adapter.Update(dataTable);
                    }
                }

                MessageBox.Show("Veriler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }

            // Optional: Refresh the data after saving changes
            VerileriDoldur();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
          
        }

        private void VerileriDoldur()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM UrunKategori";

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti))
                {
                    // DataTable oluşturulması
                    dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    adapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }
    }
}
