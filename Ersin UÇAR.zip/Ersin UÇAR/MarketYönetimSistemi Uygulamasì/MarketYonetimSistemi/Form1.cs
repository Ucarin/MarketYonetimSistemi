﻿using System.Collections.Generic;
using System.Data.SqlClient;
using System.Windows.Forms;
using System;

namespace MarketYonetimSistemi
{
    public partial class Form1 : Form
    {
        private static BaglantiDB baglantiDB; // BaglantiDB sınıfından bir örnek

        public Form1()
        {
            InitializeComponent();
            baglantiDB = new BaglantiDB(); // BaglantiDB sınıfından bir örnek oluşturun
        }

        public List<string> GetMarketIsimleri()
        {
            List<string> marketIsimleri = new List<string>();

            try
            {
                using (SqlCommand komut = new SqlCommand("SELECT MarketAdi FROM Market", baglantiDB.Baglanti))
                {
                    baglantiDB.BaglantiAc();
                    using (SqlDataReader reader = komut.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            marketIsimleri.Add(reader["MarketAdi"].ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}");
            }
            finally
            {
                baglantiDB.BaglantiKapat();
            }

            return marketIsimleri;
        }

        public int GetMarketIdByAd(string marketAd)
        {
            int marketId = -1; // Hata durumunda -1 döndürmek için varsayılan değer

            try
            {
                using (SqlCommand komut = new SqlCommand("SELECT MarketID FROM Market WHERE MarketAdi = @MarketAd", baglantiDB.Baglanti))
                {
                    komut.Parameters.AddWithValue("@MarketAd", marketAd);
                    baglantiDB.BaglantiAc();
                    object result = komut.ExecuteScalar();
                    if (result != null)
                    {
                        marketId = Convert.ToInt32(result);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Hata: {ex.Message}");
            }
            finally
            {
                baglantiDB.BaglantiKapat();
            }

            return marketId;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Form yüklendiğinde bağlantıyı açabilirsiniz
            baglantiDB.BaglantiAc();

            // Combobox'a market adlarını yükle
            cb_marketler.Items.AddRange(GetMarketIsimleri().ToArray());
        }

        private void btn_GirisYap_Click(object sender, EventArgs e)
        {
            // Seçilen marketi kontrol et
            if (cb_marketler.SelectedItem != null)
            {
                // Seçilen marketin ID'sini al
                int secilenMarketId = GetMarketIdByAd(cb_marketler.SelectedItem.ToString());

                // AnaSayfa formunu oluştururken seçilen marketin ID'sini ileterek aç
                this.Hide();
                AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
                anaSayfaGecis.Show();
            }
            else
            {
                MessageBox.Show("Lütfen bir market seçiniz.");
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            // Form kapanırken bağlantıyı kapat
            baglantiDB.BaglantiKapat();
            Application.Exit();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
