﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace MarketYonetimSistemi
{
    public partial class SatisYap : Form
    {
        private DataTable dataTable;
        private SqlDataAdapter dataAdapter;
        private BaglantiDB baglanti;
        private int secilenMarketId;

        public SatisYap(int secilenMarketId)
        {
            InitializeComponent();
            baglanti = new BaglantiDB();
            btn_kaydet.Click += Btn_kaydet_Click;

            // SatisYap formu yüklendiğinde Satis tablosunu getir
            this.secilenMarketId = secilenMarketId;
            SatisListele();
        }

        // Satis tablosunu DataGridView'da listeleme
        private void SatisListele()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM Satis WHERE MarketId = @MarketId";

                // SqlDataAdapter nesnesi oluşturulması
                dataAdapter = new SqlDataAdapter(sorgu, baglanti.Baglanti);

                // Parametre eklenmesi
                dataAdapter.SelectCommand.Parameters.AddWithValue("@MarketId", secilenMarketId);

                // DataTable oluşturulması
                dataTable = new DataTable();

                // Verilerin DataSet'e doldurulması
                dataAdapter.Fill(dataTable);

                // DataGridView'a DataSource olarak atanması
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        // DataGridView'da yapılan değişiklikleri kaydet
        private void Btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SqlCommandBuilder nesnesi oluşturulması
                using (SqlCommandBuilder builder = new SqlCommandBuilder(dataAdapter))
                {
                    // DataTable'daki değişiklikleri kaydet
                    dataAdapter.Update(dataTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
                SatisListele();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        

        

        private void button1_Click(object sender, EventArgs e)
        {
            StokDurumu stokDurumuGecis = new StokDurumu(secilenMarketId);
            stokDurumuGecis.Show();
        }

        private void SatisYap_Load(object sender, EventArgs e)
        {

        }

        private void SatisYap_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();
        }
    }
}
