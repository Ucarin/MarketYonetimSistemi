﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class SatınAlımYonetimi : Form
    {
        private int secilenMarketId;
        private DataTable dataTable;
        private SqlDataAdapter dataAdapter;
        private BaglantiDB baglanti;

        public SatınAlımYonetimi(int secilenMarketId)
        {
            InitializeComponent();
            this.secilenMarketId = secilenMarketId;
            baglanti = new BaglantiDB();
            btn_kaydet.Click += Btn_kaydet_Click;

            // SatinAlimYonetimi formu yüklendiğinde SatinAlim tablosunu getir
            SatinAlimListele();
        }

        // SatinAlim tablosunu DataGridView'da listeleme
        private void SatinAlimListele()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM SatinAlim WHERE MarketId = @MarketId";

                // SqlDataAdapter nesnesi oluşturulması
                dataAdapter = new SqlDataAdapter(sorgu, baglanti.Baglanti);

                // Parametre eklenmesi
                dataAdapter.SelectCommand.Parameters.AddWithValue("@MarketId", secilenMarketId);

                // DataTable oluşturulması
                dataTable = new DataTable();

                // Verilerin DataSet'e doldurulması
                dataAdapter.Fill(dataTable);

                // DataGridView'a DataSource olarak atanması
                dataGridView1.DataSource = dataTable;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        // DataGridView'da yapılan değişiklikleri kaydet
        private void Btn_kaydet_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SqlCommandBuilder nesnesi oluşturulması
                using (SqlCommandBuilder builder = new SqlCommandBuilder(dataAdapter))
                {
                    // DataTable'daki değişiklikleri kaydet
                    dataAdapter.Update(dataTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
                SatinAlimListele();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        private void SatınAlımYonetimi_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Hide();
            AnaSayfa anaSayfaGecis = new AnaSayfa(secilenMarketId);
            anaSayfaGecis.Show();

        }

        private void SatınAlımYonetimi_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void btn_SatinAlimDetay_Click(object sender, EventArgs e)
        {
            SatinAlimDetay satinAlimDetayGecis = new SatinAlimDetay(secilenMarketId);
            satinAlimDetayGecis.Show();
        }
    }
}
