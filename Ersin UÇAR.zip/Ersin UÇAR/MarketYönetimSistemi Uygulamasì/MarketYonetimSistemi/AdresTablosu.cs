﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace MarketYonetimSistemi
{
    public partial class AdresTablosu : Form
    {
        private BaglantiDB baglanti;
        private DataTable dataTable;

        public AdresTablosu()
        {
            InitializeComponent();
            baglanti = new BaglantiDB();

            // Form yüklenirken Adres tablosunu listeleyelim
            AdresListele();
        }

        // Adres tablosunu DataGridView'da listeleme
        private void AdresListele()
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // SQL sorgusu
                string sorgu = "SELECT * FROM Adres";

                // SqlDataAdapter nesnesi oluşturulması
                using (SqlDataAdapter adapter = new SqlDataAdapter(sorgu, baglanti.Baglanti))
                {
                    // DataTable oluşturulması
                    dataTable = new DataTable();

                    // Verilerin DataSet'e doldurulması
                    adapter.Fill(dataTable);

                    // DataGridView'a DataSource olarak atanması
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        // DataGridView'da hücre düzenlendiğinde
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // DataGridView'da yapılan değişiklikleri veritabanına kaydet
                using (SqlCommandBuilder builder = new SqlCommandBuilder())
                {
                    builder.DataAdapter = new SqlDataAdapter("SELECT * FROM Adres", baglanti.Baglanti);

                    // DataTable'daki değişiklikleri kaydet
                    builder.DataAdapter.Update(dataTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                baglanti.BaglantiKapat();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Bağlantıyı aç
                baglanti.BaglantiAc();

                // DataGridView'da yapılan değişiklikleri veritabanına kaydet
                using (SqlCommandBuilder builder = new SqlCommandBuilder())
                {
                    builder.DataAdapter = new SqlDataAdapter("SELECT * FROM Adres", baglanti.Baglanti);

                    // DataTable'daki değişiklikleri kaydet
                    builder.DataAdapter.Update(dataTable);
                }

                MessageBox.Show("Değişiklikler başarıyla kaydedildi.");
                AdresListele(); // DataGridView'i güncelle
            }
            catch (Exception ex)
            {
                MessageBox.Show("Hata: " + ex.Message);
            }
            finally
            {
                // Bağlantıyı kapat
                baglanti.BaglantiKapat();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
